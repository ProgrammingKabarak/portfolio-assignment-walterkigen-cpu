const quotes = [
  { text: "The only way to do great work is to love what you do.", author: "Steve Jobs" },
  { text: "Code is like humor. When you have to explain it, it's bad.", author: "Cory House" },
  { text: "First, solve the problem. Then, write the code.", author: "John Johnson" },
  { text: "Experience is the name everyone gives to their mistakes.", author: "Oscar Wilde" },
  { text: "Simplicity is the soul of efficiency.", author: "Austin Freeman" },
  { text: "Make it work, make it right, make it fast.", author: "Kent Beck" },
  { text: "The best error message is the one that never shows up.", author: "Thomas Fuchs" },
  { text: "Talk is cheap. Show me the code.", author: "Linus Torvalds" },
];

const quoteText = document.getElementById('quote-text');
const quoteAuthor = document.getElementById('quote-author');
const newQuoteBtn = document.getElementById('new-quote-btn');
const copyBtn = document.getElementById('copy-btn');
const copyStatus = document.getElementById('copy-status');
const tweetLink = document.getElementById('tweet-link');

let current = quotes[0];

function showRandomQuote() {
  let next;
  do {
    next = quotes[Math.floor(Math.random() * quotes.length)];
  } while (next.text === current.text && quotes.length > 1);

  current = next;
  quoteText.style.opacity = 0;

  setTimeout(() => {
    quoteText.textContent = current.text;
    quoteAuthor.textContent = `— ${current.author}`;
    quoteText.style.opacity = 1;
    copyStatus.textContent = '';

    const tweetText = encodeURIComponent(`"${current.text}" — ${current.author}`);
    tweetLink.href = `https://twitter.com/intent/tweet?text=${tweetText}`;
  }, 200);
}

copyBtn.addEventListener('click', async () => {
  try {
    await navigator.clipboard.writeText(`"${current.text}" — ${current.author}`);
    copyStatus.textContent = 'Copied to clipboard!';
  } catch {
    copyStatus.textContent = 'Could not copy — select and copy manually.';
  }
});

newQuoteBtn.addEventListener('click', showRandomQuote);

showRandomQuote();
